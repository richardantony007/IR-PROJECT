
import time
import pandas as pd

from sklearn.datasets import (
    load_iris,
    load_wine,
    load_breast_cancer,
    load_digits
)
from sklearn.model_selection import (
    train_test_split,
    cross_val_score,
    StratifiedKFold
)
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.neighbors import KNeighborsClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score
)

# Load four datasets initially.
# Add four more from the UCI repository for a
# broader evaluation.
datasets = {
    "Iris": load_iris(),
    "Wine": load_wine(),
    "Breast Cancer": load_breast_cancer(),
    "Digits": load_digits()
}

models = {
    "KNN": make_pipeline(
        StandardScaler(),
        KNeighborsClassifier(n_neighbors=5)
    ),
    "Decision Tree": DecisionTreeClassifier(
        random_state=42
    ),
    "Random Forest": RandomForestClassifier(
        n_estimators=200,
        random_state=42
    )
}

cv = StratifiedKFold(
    n_splits=5, shuffle=True, random_state=42
)

results = []

for dataset_name, dataset in datasets.items():
    X, y = dataset.data, dataset.target

    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=0.20,
        random_state=42,
        stratify=y
    )

    for model_name, model in models.items():
        start = time.perf_counter()

        # Cross-validation on training data only
        cv_scores = cross_val_score(
            model, X_train, y_train,
            cv=cv, scoring="f1_macro"
        )

        # Fit final model on the training split
        model.fit(X_train, y_train)
        train_time = time.perf_counter() - start

        predictions = model.predict(X_test)

        results.append({
            "Dataset": dataset_name,
            "Algorithm": model_name,
            "CV Macro F1": cv_scores.mean(),
            "Accuracy": accuracy_score(
                y_test, predictions
            ),
            "Precision": precision_score(
                y_test, predictions,
                average="macro", zero_division=0
            ),
            "Recall": recall_score(
                y_test, predictions,
                average="macro", zero_division=0
            ),
            "Test Macro F1": f1_score(
                y_test, predictions,
                average="macro", zero_division=0
            ),
            "Training + CV Time (s)": train_time
        })

df = pd.DataFrame(results)

# Compare average cross-validation performance
summary = (
    df.groupby("Algorithm")
      .agg(
          Mean_CV_F1=("CV Macro F1", "mean"),
          Mean_Accuracy=("Accuracy", "mean"),
          Mean_Test_F1=("Test Macro F1", "mean")
      )
      .sort_values("Mean_CV_F1", ascending=False)
)

summary["Rank"] = range(1, len(summary) + 1)

print("\nDataset-wise comparison:")
print(df.round(4).to_string(index=False))

print("\nOverall algorithm ranking:")
print(summary.round(4))
